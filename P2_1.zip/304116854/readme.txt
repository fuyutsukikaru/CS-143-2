Name: Soomin Jeong
UID: 304116854
Email: sjeongus@ucla.edu

Name: Jonathan Chu
UID: 804141479
Email: jonmchu@ucla.edu


